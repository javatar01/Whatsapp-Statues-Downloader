package javatar.ficdev.com.whatsappstatuesdownloader;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Html;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.MediaController;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

import com.squareup.picasso.Picasso;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.channels.FileChannel;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        RecyclerView recyclerView = (RecyclerView) findViewById(R.id.m_RecyclerView);
        recyclerView.setHasFixedSize(true);

        GridLayoutManager gridLayoutManager = new GridLayoutManager(this, 1);
        recyclerView.setLayoutManager(gridLayoutManager);

        recyclerView.setAdapter(new AuditAdapter(getData(),this));
    }

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    private void copyFile(File src, File dst) throws IOException {
        FileInputStream inStream = new FileInputStream(src);
        FileOutputStream outStream = new FileOutputStream(dst);
        FileChannel inChannel = inStream.getChannel();
        FileChannel outChannel = outStream.getChannel();
        inChannel.transferTo(0, inChannel.size(), outChannel);
        inStream.close();
        outStream.close();
    }
    public static class Statue {

        private String name;
        private String uri;
        private String path;

        private boolean video;

        public boolean isVideo() {
            return video;
        }

        public void setVideo(boolean video) {
            this.video = video;
        }

        public String getPath() {
            return path;
        }

        public void setPath(String path) {
            this.path = path;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getUri() {
            return uri;
        }

        public void setUri(String uri) {
            this.uri = uri;
        }
    }

    private ArrayList<Statue> getData()
    {
        ArrayList<Statue> spacecrafts=new ArrayList<>();
        //TARGET FOLDER
        String dir = Environment.getExternalStorageDirectory()+"/WhatsApp/Media/.Statuses";
        File downloadsFolder = new File(dir);

        if(downloadsFolder.isDirectory())
        {
            //GET ALL FILES IN DOWNLOAD FOLDER
            File[] files=downloadsFolder.listFiles();


            //LOOP THRU THOSE FILES GETTING NAME AND URI
            for (File file : files) {
                //Toast.makeText(this, ""+file.get, Toast.LENGTH_SHORT).show();
                Statue s = new Statue();
                s.setName(file.getName());
                s.setUri(file.getAbsolutePath());
                s.setPath(file.getPath());
                s.setVideo(file.getName().contains(".mp4"));
                spacecrafts.add(s);
            }

        }

        return spacecrafts;
    }


    class AuditAdapter extends RecyclerView.Adapter<AuditAdapter.ViewHolder> {

        private List<Statue> List_Item;

        AuditAdapter(List<Statue> list_Item, Context context) {
            List_Item = list_Item;
        }

        @Override
        public AuditAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

            View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.statue_item, parent, false);
            return new ViewHolder(v);
        }

        @SuppressLint("SetTextI18n")
        @Override
        public void onBindViewHolder(final AuditAdapter.ViewHolder holder, final int position) {
            final Statue statue = List_Item.get(position);
            if(statue.isVideo()){
                holder.image.setVisibility(View.GONE);
                holder.video.setVisibility(View.VISIBLE);
                holder.button.setVisibility(View.VISIBLE);
                holder.imageButton.setVisibility(View.VISIBLE);

                holder.video.setVideoURI(Uri.parse(statue.getPath()));

                holder.video.requestFocus();
                holder.video.pause();
                holder.button.setText("play");
                holder.button.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        if(holder.video.isPlaying()){
                            holder.video.pause();
                            holder.button.setText("play");
                        }else {
                            holder.video.start();
                            holder.button.setText("stop");
                        }
                    }
                });

                holder.imageButton.setOnClickListener(new View.OnClickListener() {
                    @SuppressLint({"ResourceAsColor", "SetTextI18n"})
                    @Override
                    public void onClick(View view) {
                        save(statue.getPath(),".mp4");
                    }
                });

            }else {
                Bitmap myBitmap = BitmapFactory.decodeFile(statue.getUri());
                holder.image.setImageBitmap(myBitmap);
                holder.image.setVisibility(View.VISIBLE);
                holder.video.setVisibility(View.GONE);
                holder.button.setVisibility(View.GONE);
                holder.imageButton.setVisibility(View.GONE);
                holder.image.setOnClickListener(new View.OnClickListener() {
                    @SuppressLint({"ResourceAsColor", "SetTextI18n"})
                    @Override
                    public void onClick(View view) {
                        save(statue.getPath(),".jpg");
                    }
                });
            }


        }

        @SuppressLint({"ResourceAsColor", "SetTextI18n"})
        void save(final String path, final String type){
            final AlertDialog dialog2 = new AlertDialog.Builder(MainActivity.this).create();
            final EditText text = new EditText(MainActivity.this);
            text.setTextColor(R.color.colorPrimaryDark);
            dialog2.setView(text);
            final String dir = Environment.getExternalStorageDirectory()+"/WhatsApp Statues";
            File f = new File(dir);

            text.setText("statues" +f.listFiles().length);
            text.requestFocus();
            dialog2.setTitle(Html.fromHtml("<font color='#000000'>Save this statue </font>"));
            dialog2.setButton(DialogInterface.BUTTON_POSITIVE, "Save", new DialogInterface.OnClickListener() {
                @SuppressLint("SetTextI18n")
                @RequiresApi(api = Build.VERSION_CODES.KITKAT)
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    String s = text.getText().toString();
                    try {
                        copyFile(new File(path),new File(dir+ "/"+s+type));
                        Toast.makeText(MainActivity.this, "Saved in /WhatsApp Statues", Toast.LENGTH_SHORT).show();
                    } catch (IOException e) {
                        Toast.makeText(MainActivity.this, e.toString(), Toast.LENGTH_SHORT).show();
                    }
                }
            });
            dialog2.setButton(DialogInterface.BUTTON_NEGATIVE, "Cancel", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                }
            });
            dialog2.show();
        }

        @Override
        public int getItemCount() {
            return (null != List_Item ? List_Item.size() : 0);
        }

        protected class ViewHolder extends RecyclerView.ViewHolder {
            ImageView image;
            VideoView video;
            Button button;
            ImageButton imageButton;
            public ViewHolder(View view) {
                super(view);

                image = (ImageView) view.findViewById(R.id.imageView);
                video = (VideoView) view.findViewById(R.id.videoView);
                button = (Button) view.findViewById(R.id.button);
                imageButton = (ImageButton) view.findViewById(R.id.imageButton);
            }
        }
    }
}

